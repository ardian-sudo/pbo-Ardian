-- ============================================================
-- DATABASE: db_klinik
-- Aplikasi: Sistem Informasi Klinik Sederhana
-- Mata Kuliah: Pemrograman Berbasis Objek (Java)
-- ============================================================

CREATE DATABASE IF NOT EXISTS db_klinik;
USE db_klinik;

-- ------------------------------------------------------------
-- Tabel 1: users (untuk login aplikasi)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(50) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'petugas'
);

INSERT INTO users (username, password, role) VALUES
('admin', 'admin123', 'admin'),
('petugas1', 'petugas123', 'petugas');

-- ------------------------------------------------------------
-- Tabel 2: pasien (data master pasien)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pasien (
    id INT AUTO_INCREMENT PRIMARY KEY,
    no_rm VARCHAR(20) NOT NULL UNIQUE,
    nama VARCHAR(100) NOT NULL,
    alamat VARCHAR(200),
    tgl_lahir DATE,
    jenis_kelamin ENUM('L','P') NOT NULL,
    no_telp VARCHAR(20)
);

INSERT INTO pasien (no_rm, nama, alamat, tgl_lahir, jenis_kelamin, no_telp) VALUES
('RMA0001', 'Ahmad Fauzi', 'Jl. Merdeka No. 10, Sukabumi', '1995-03-12', 'L', '081234567890'),
('RMS0002', 'Siti Nurhaliza', 'Jl. Kenanga No. 5, Cimahi', '2000-07-22', 'P', '082198765432'),
('RMB0003', 'Budi Santoso', 'Jl. Anggrek No. 8, Padalarang', '1988-11-02', 'L', '085711223344');

-- ------------------------------------------------------------
-- Tabel 3: dokter (data master dokter)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dokter (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    spesialisasi VARCHAR(100) NOT NULL,
    no_telp VARCHAR(20)
);

INSERT INTO dokter (nama, spesialisasi, no_telp) VALUES
('Dr. Rina Wijaya', 'Umum', '081122334455'),
('Dr. Hendra Kusuma', 'Anak', '081299887766');

-- ------------------------------------------------------------
-- Tabel 4: obat (data master obat)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS obat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_obat VARCHAR(100) NOT NULL,
    stok INT NOT NULL DEFAULT 0,
    harga DECIMAL(10,2) NOT NULL DEFAULT 0
);

INSERT INTO obat (nama_obat, stok, harga) VALUES
('Paracetamol 500mg', 100, 2000),
('Amoxicillin 500mg', 80, 3500),
('Vitamin C', 150, 1500),
('Antasida Tablet', 60, 2500);

-- ------------------------------------------------------------
-- Tabel 5: transaksi (transaksi pemeriksaan pasien)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_pasien INT NOT NULL,
    id_dokter INT NOT NULL,
    tanggal DATE NOT NULL,
    keluhan VARCHAR(255),
    diagnosa VARCHAR(255),
    total_biaya DECIMAL(12,2) DEFAULT 0,
    FOREIGN KEY (id_pasien) REFERENCES pasien(id) ON DELETE CASCADE,
    FOREIGN KEY (id_dokter) REFERENCES dokter(id) ON DELETE CASCADE
);

-- ------------------------------------------------------------
-- Tabel 6: detail_resep (detail obat pada setiap transaksi)
-- Relasi many-to-many antara transaksi dan obat
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS detail_resep (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_transaksi INT NOT NULL,
    id_obat INT NOT NULL,
    jumlah INT NOT NULL,
    subtotal DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (id_transaksi) REFERENCES transaksi(id) ON DELETE CASCADE,
    FOREIGN KEY (id_obat) REFERENCES obat(id)
);

-- ============================================================
-- Catatan:
-- - Total tabel: 6 (melebihi ketentuan minimal 4 tabel)
-- - Struktur ini mendukung CRUD lengkap dan pencarian data
--   pada pasien, dokter, obat, dan transaksi.
-- ============================================================
